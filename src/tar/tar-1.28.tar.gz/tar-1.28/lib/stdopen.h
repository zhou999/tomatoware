#ifndef STDOPEN_H
# define STDOPEN_H 1

# include <stdbool.h>

# ifdef __cplusplus
extern "C" {
# endif

bool stdopen (void);

# ifdef __cplusplus
}
# endif

#endif
