#define anytostr uinttostr
#define inttype unsigned int
#include "anytostr.c"
