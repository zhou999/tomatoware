#define dfoo_foo2_h
// The include below is not valid syntax and should be ignored.
#include ../dbar/foo.h  
