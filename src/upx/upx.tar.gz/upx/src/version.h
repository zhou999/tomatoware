#define UPX_VERSION_HEX         0x035c00        /* 03.92.00 */
#define UPX_VERSION_STRING      "3.92"
#define UPX_VERSION_STRING4     "3.92"
#define UPX_VERSION_DATE        "Mar 30th 2015"
#define UPX_VERSION_DATE_ISO    "2015-03-30"
#define UPX_VERSION_YEAR        "2015"
